#!/usr/bin/env bash
set -euo pipefail
INPUT="${1:-security_events.jsonl}"
OUT="${2:-reports}"
python3 src/ad_fake_account_detector.py --input "$INPUT" --out "$OUT"
